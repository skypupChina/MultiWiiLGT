# LarduinoISP
make arduino board to be an ISP of LGT8FX8D/P series MCU

![](https://image.geek-workshop.com/forum/201604/03/110353eiiwydix7fx7aw7t.png)
